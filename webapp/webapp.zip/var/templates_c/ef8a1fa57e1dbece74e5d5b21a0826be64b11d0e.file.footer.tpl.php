<?php /* Smarty version Smarty-3.1.19, created on 2018-12-27 15:11:53
         compiled from "C:\xampp\htdocs\projects\tanakakaikei\sys\trunk\webapp\templates\admin\common\footer.tpl" */ ?>
<?php /*%%SmartyHeaderCode:134025c246d290b3f18-34160614%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'ef8a1fa57e1dbece74e5d5b21a0826be64b11d0e' => 
    array (
      0 => 'C:\\xampp\\htdocs\\projects\\tanakakaikei\\sys\\trunk\\webapp\\templates\\admin\\common\\footer.tpl',
      1 => 1540280464,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '134025c246d290b3f18-34160614',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    '_js' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.19',
  'unifunc' => 'content_5c246d290b68e7_31548505',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5c246d290b68e7_31548505')) {function content_5c246d290b68e7_31548505($_smarty_tpl) {?>
    
    <!-- /footer -->
</div>
<?php echo $_smarty_tpl->tpl_vars['_js']->value;?>

</body>
</html>
<?php }} ?>
