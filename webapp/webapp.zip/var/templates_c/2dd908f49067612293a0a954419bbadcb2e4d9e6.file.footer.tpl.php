<?php /* Smarty version Smarty-3.1.19, created on 2018-12-27 12:49:12
         compiled from "C:\xampp\htdocs\projects\tanakakaikei\sys\trunk\webapp\templates\common\footer.tpl" */ ?>
<?php /*%%SmartyHeaderCode:122695c244bb87e7123-99738016%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '2dd908f49067612293a0a954419bbadcb2e4d9e6' => 
    array (
      0 => 'C:\\xampp\\htdocs\\projects\\tanakakaikei\\sys\\trunk\\webapp\\templates\\common\\footer.tpl',
      1 => 1545009489,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '122695c244bb87e7123-99738016',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    '_js' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.19',
  'unifunc' => 'content_5c244bb87ea374_49190521',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5c244bb87ea374_49190521')) {function content_5c244bb87ea374_49190521($_smarty_tpl) {?>
    
    <!-- /footer -->
</div>
<?php echo $_smarty_tpl->tpl_vars['_js']->value;?>

</body>
</html>
<?php }} ?>
