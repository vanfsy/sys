<?php /* Smarty version Smarty-3.1.19, created on 2019-01-17 17:35:07
         compiled from "/home/users/0/sub.jp-t-cpta/web/sys/webapp/templates/common/footer.tpl" */ ?>
<?php /*%%SmartyHeaderCode:9552510255c403e3b9676f1-17341387%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '686eb71abcca8bb1523e11a7fe8e2b9c4c31eb28' => 
    array (
      0 => '/home/users/0/sub.jp-t-cpta/web/sys/webapp/templates/common/footer.tpl',
      1 => 1545009480,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '9552510255c403e3b9676f1-17341387',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    '_js' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.19',
  'unifunc' => 'content_5c403e3b968929_57736667',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5c403e3b968929_57736667')) {function content_5c403e3b968929_57736667($_smarty_tpl) {?>
    
    <!-- /footer -->
</div>
<?php echo $_smarty_tpl->tpl_vars['_js']->value;?>

</body>
</html>
<?php }} ?>
