<?php /* Smarty version Smarty-3.1.19, created on 2019-01-17 13:05:08
         compiled from "/home/users/0/sub.jp-t-cpta/web/sys/webapp/templates/admin/common/footer.tpl" */ ?>
<?php /*%%SmartyHeaderCode:10707969435c3ffef4346a19-58094912%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'f7df462c821103480b433bf821349d610f95c8ea' => 
    array (
      0 => '/home/users/0/sub.jp-t-cpta/web/sys/webapp/templates/admin/common/footer.tpl',
      1 => 1540280460,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '10707969435c3ffef4346a19-58094912',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    '_js' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.19',
  'unifunc' => 'content_5c3ffef4347cc2_85387426',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5c3ffef4347cc2_85387426')) {function content_5c3ffef4347cc2_85387426($_smarty_tpl) {?>
    
    <!-- /footer -->
</div>
<?php echo $_smarty_tpl->tpl_vars['_js']->value;?>

</body>
</html>
<?php }} ?>
