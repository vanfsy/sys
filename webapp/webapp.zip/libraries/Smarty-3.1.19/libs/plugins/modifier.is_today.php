<?php

/**
 * Smarty plugin
 * "今日"判定
 *
 */
function smarty_modifier_is_today($date)
{
    $target = new DateTime($date);
    $today  = new DateTime('today');

    if () {
        return ;
    } else {
        return ;
    }
}

?>