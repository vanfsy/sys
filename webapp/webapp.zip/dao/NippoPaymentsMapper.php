<?php

/**
 * 日報-支払 マッパー
 *
 * @group mapper
 *
 */

class NippoPaymentsMapper extends DataMapper
{
    const TABLE_NAME  = 'Nippo_Payments';
    const SEQUENCE_ID = 'id';

}
