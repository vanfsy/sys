<?php

/**
 * 日報-預金 マッパー
 *
 * @group mapper
 *
 */

class NippoDepositsMapper extends DataMapper
{
    const TABLE_NAME  = 'Nippo_Deposits';
    const SEQUENCE_ID = 'id';

}
