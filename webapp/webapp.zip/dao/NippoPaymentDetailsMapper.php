<?php

/**
 * 日報-支払-明細 マッパー
 *
 * @group mapper
 *
 */

class NippoPaymentDetailsMapper extends DataMapper
{
    const TABLE_NAME  = 'Nippo_Payment_Details';
    const SEQUENCE_ID = 'id';
}
